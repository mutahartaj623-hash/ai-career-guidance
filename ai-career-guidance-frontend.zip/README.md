# PathFinder AI — Career Guidance Frontend

A responsive React + Vite frontend starter for an AI-based career guidance platform.

## Requirements
- Node.js 18+ and npm
- Python Flask backend (optional for demo mode)

## Run locally
```bash
npm install
cp .env.example .env
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Build
```bash
npm run build
npm run preview
```

## Demo mode and Flask integration
The app starts in demo mode (`VITE_USE_DEMO_DATA=true`) so screens and interactions work without a backend. Demo career matches are illustrative and are not AI predictions.

To connect Flask:
1. Set `VITE_USE_DEMO_DATA=false` in `.env`.
2. Set `VITE_API_BASE_URL` to your Flask server.
3. Implement the endpoints documented in `src/services/api.js`.
4. Ensure Flask enables CORS for the Vite origin.
5. For production, prefer secure, HttpOnly cookies for authentication. This starter keeps a demo session in sessionStorage; do not treat it as production-grade token storage.

## Main routes
- `/` Landing page
- `/login`, `/register`
- `/app/dashboard`
- `/app/assessment`
- `/app/recommendations`, `/app/careers`
- `/app/careers/:id`
- `/app/roadmap`, `/app/courses`, `/app/internships`
- `/app/skills`, `/app/notifications`, `/app/profile`, `/app/settings`
- `/admin`

## Notes
- Admin route is a UI demonstration. Add server-side role checks before production use.
- Salary ranges and match scores in demo data are sample content. Replace them with sourced backend data.
