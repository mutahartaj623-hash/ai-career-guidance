import { Navigate, Route, Routes } from "react-router-dom";
import { LandingPage,LoginPage,RegisterPage } from "./pages/PublicPages";
import { Dashboard,Assessment,Recommendations,CareerExplorer,CareerDetails,Roadmap,Courses,Internships,Skills,Notifications,Profile,Settings,AdminDashboard } from "./pages/AppPages";
import { AppLayout } from "./components/Layout";
import ProtectedRoute from "./routes/ProtectedRoute";
export default function App(){return <Routes>
 <Route path="/" element={<LandingPage/>}/><Route path="/login" element={<LoginPage/>}/><Route path="/register" element={<RegisterPage/>}/>
 <Route element={<ProtectedRoute/>}><Route path="/app" element={<AppLayout/>}>
  <Route index element={<Navigate to="dashboard" replace/>}/><Route path="dashboard" element={<Dashboard/>}/><Route path="assessment" element={<Assessment/>}/><Route path="recommendations" element={<Recommendations/>}/><Route path="careers" element={<CareerExplorer/>}/><Route path="careers/:id" element={<CareerDetails/>}/><Route path="roadmap" element={<Roadmap/>}/><Route path="courses" element={<Courses/>}/><Route path="internships" element={<Internships/>}/><Route path="skills" element={<Skills/>}/><Route path="notifications" element={<Notifications/>}/><Route path="profile" element={<Profile/>}/><Route path="settings" element={<Settings/>}/>
 </Route></Route>
 <Route element={<ProtectedRoute role="admin"/>}><Route path="/admin" element={<AppLayout/>}><Route index element={<AdminDashboard/>}/></Route></Route>
 <Route path="*" element={<Navigate to="/" replace/>}/>
 </Routes>}
