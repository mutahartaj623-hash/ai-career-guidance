export const careers = [
 {id:"ai-engineer",title:"AI Engineer",category:"Technology",match:94,description:"Design intelligent systems and integrate machine learning models into real-world products.",salary:"₹6–18 LPA",demand:"Very high",growth:"Excellent",skills:["Python","Machine Learning","数学 / Statistics","APIs"],education:"B.Tech / B.Sc. in CS or related field",certs:["Machine Learning Specialization","Azure AI Fundamentals"],color:"violet"},
 {id:"data-scientist",title:"Data Scientist",category:"Data",match:89,description:"Turn complex datasets into insights, predictive models and business decisions.",salary:"₹5–16 LPA",demand:"High",growth:"Excellent",skills:["Python","SQL","Statistics","Data Visualization"],education:"CS, Statistics, Mathematics or related degree",certs:["Google Data Analytics","IBM Data Science"],color:"blue"},
 {id:"full-stack",title:"Full Stack Developer",category:"Technology",match:86,description:"Build complete web applications across frontend interfaces and backend services.",salary:"₹4–12 LPA",demand:"Very high",growth:"High",skills:["JavaScript","React","Node.js","Databases"],education:"Any relevant degree or strong portfolio",certs:["Meta Front-End Developer","AWS Cloud Practitioner"],color:"green"},
 {id:"cybersecurity",title:"Cybersecurity Analyst",category:"Security",match:78,description:"Protect applications, networks and data by identifying and responding to security risks.",salary:"₹4–14 LPA",demand:"High",growth:"High",skills:["Networking","Linux","Security tools","Risk analysis"],education:"CS, IT or cybersecurity qualification",certs:["CompTIA Security+","Google Cybersecurity"],color:"orange"},
 {id:"cloud-engineer",title:"Cloud Engineer",category:"Cloud",match:74,description:"Build, deploy and maintain scalable cloud infrastructure and services.",salary:"₹5–15 LPA",demand:"High",growth:"High",skills:["Linux","AWS / Azure","Networking","Docker"],education:"CS, IT or equivalent practical experience",certs:["AWS Solutions Architect","Azure Fundamentals"],color:"blue"},
 {id:"business-analyst",title:"Business Analyst",category:"Business",match:72,description:"Connect business needs with data, processes and technology solutions.",salary:"₹4–11 LPA",demand:"High",growth:"High",skills:["SQL","Excel","Communication","Problem solving"],education:"Business, Engineering or related degree",certs:["ECBA","Google Business Intelligence"],color:"purple"},
 {id:"uiux",title:"UI/UX Designer",category:"Design",match:69,description:"Create intuitive digital experiences through research, interaction and visual design.",salary:"₹3–10 LPA",demand:"Growing",growth:"High",skills:["Figma","User research","Prototyping","Visual design"],education:"Any degree with a strong design portfolio",certs:["Google UX Design"],color:"pink"},
 {id:"ml-engineer",title:"Machine Learning Engineer",category:"Data",match:67,description:"Develop, evaluate and deploy machine learning systems at production scale.",salary:"₹6–20 LPA",demand:"Very high",growth:"Excellent",skills:["Python","ML algorithms","MLOps","Cloud"],education:"CS, Mathematics or related degree",certs:["DeepLearning.AI ML Engineering"],color:"violet"}
];
export const courses = [
 {id:1,title:"Python for Everybody",provider:"University of Michigan",level:"Beginner",duration:"8 weeks",price:"Free to audit",category:"Programming",cert:true},
 {id:2,title:"Machine Learning Specialization",provider:"DeepLearning.AI",level:"Intermediate",duration:"3 months",price:"Paid certificate",category:"AI & Data",cert:true},
 {id:3,title:"Google UX Design Professional",provider:"Google",level:"Beginner",duration:"6 months",price:"Subscription",category:"Design",cert:true},
 {id:4,title:"Full-Stack Web Development",provider:"Meta",level:"Intermediate",duration:"4 months",price:"Subscription",category:"Development",cert:true},
 {id:5,title:"Introduction to Cybersecurity",provider:"Cisco Networking Academy",level:"Beginner",duration:"6 hours",price:"Free",category:"Security",cert:true}
];
export const internships = [
 {id:1,role:"Frontend Developer Intern",company:"BrightLabs",location:"Bengaluru / Remote",type:"Remote",stipend:"₹15,000/month",skills:["React","JavaScript","CSS"],deadline:"30 Dec 2026"},
 {id:2,role:"Data Analytics Intern",company:"InsightWorks",location:"Hyderabad",type:"On-site",stipend:"₹12,000/month",skills:["Python","SQL","Excel"],deadline:"12 Dec 2026"},
 {id:3,role:"AI Research Intern",company:"NeuralBridge",location:"Remote",type:"Remote",stipend:"₹20,000/month",skills:["Python","ML","Statistics"],deadline:"05 Jan 2027"},
 {id:4,role:"Cybersecurity Intern",company:"SecureStack",location:"Chennai",type:"Hybrid",stipend:"₹10,000/month",skills:["Linux","Networking","Security"],deadline:"18 Dec 2026"}
];
export const notifications = [
 {id:1,title:"Your career assessment is ready",body:"Complete your assessment to unlock personalized career matches.",time:"10 min ago",type:"assessment",read:false},
 {id:2,title:"New learning recommendation",body:"A Python course has been added to your suggested learning path.",time:"Yesterday",type:"course",read:false},
 {id:3,title:"Internship match found",body:"A remote frontend internship matches your selected skills.",time:"2 days ago",type:"job",read:true}
];
