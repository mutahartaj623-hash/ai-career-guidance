import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:5000",
  timeout: 12000,
  withCredentials: true
});

// Demo mode keeps the UI usable before the Flask API is available.
export const DEMO_MODE = import.meta.env.VITE_USE_DEMO_DATA !== "false";

api.interceptors.response.use(
  response => response,
  error => Promise.reject(new Error(error.response?.data?.message || error.message || "Request failed"))
);

export const endpoints = {
  register: data => api.post("/api/auth/register", data),
  login: data => api.post("/api/auth/login", data),
  dashboard: () => api.get("/api/student/dashboard"),
  submitAssessment: data => api.post("/api/assessment/submit", data),
  recommendations: () => api.get("/api/career/recommendations"),
  careerDetails: id => api.get(`/api/career/details/${id}`),
  roadmap: () => api.get("/api/learning-roadmap"),
  courses: () => api.get("/api/courses"),
  internships: () => api.get("/api/internships"),
  skillGap: () => api.get("/api/skill-gap"),
  notifications: () => api.get("/api/notifications"),
  profile: () => api.get("/api/profile")
};
export default api;
