import { createContext, useContext, useMemo, useState } from "react";
import { DEMO_MODE, endpoints } from "../services/api";

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem("pathfinder-user")) || null; } catch { return null; }
  });
  const [loading, setLoading] = useState(false);

  const login = async (email, password) => {
    setLoading(true);
    try {
      let profile;
      if (DEMO_MODE) {
        await new Promise(r => setTimeout(r, 350));
        profile = { name: email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, c => c.toUpperCase()), email, role: email.toLowerCase().includes("admin") ? "admin" : "student" };
      } else {
        const { data } = await endpoints.login({ email, password });
        profile = data.user || data;
      }
      setUser(profile); sessionStorage.setItem("pathfinder-user", JSON.stringify(profile)); return profile;
    } finally { setLoading(false); }
  };
  const register = async payload => {
    setLoading(true);
    try {
      if (!DEMO_MODE) await endpoints.register(payload);
      const profile = { name: payload.name, email: payload.email, role: "student" };
      setUser(profile); sessionStorage.setItem("pathfinder-user", JSON.stringify(profile)); return profile;
    } finally { setLoading(false); }
  };
  const logout = () => { setUser(null); sessionStorage.removeItem("pathfinder-user"); };
  const value = useMemo(() => ({ user, loading, login, register, logout }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
