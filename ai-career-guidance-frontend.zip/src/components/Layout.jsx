import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { Activity, Award, Bell, BookOpen, BriefcaseBusiness, ChartNoAxesCombined, ChevronLeft, ChevronRight, Compass, GraduationCap, LayoutDashboard, LogOut, Menu, Settings, ShieldCheck, Sparkles, UserRound, X } from "lucide-react";
import { useAuth } from "../context/AuthContext";

const studentNav = [
 ["Overview","/app/dashboard",LayoutDashboard],["Career Assessment","/app/assessment",Activity],["AI Recommendations","/app/recommendations",Sparkles],
 ["Career Explorer","/app/careers",Compass],["Learning Roadmap","/app/roadmap",ChartNoAxesCombined],["Courses & Certifications","/app/courses",BookOpen],
 ["Internships & Jobs","/app/internships",BriefcaseBusiness],["Skill Gap Analysis","/app/skills",Award],["Notifications","/app/notifications",Bell],
 ["My Profile","/app/profile",UserRound],["Settings","/app/settings",Settings]
];
const adminNav = [["Admin Overview","/admin",LayoutDashboard],["Students","/admin?tab=students",UserRound],["Career Management","/admin?tab=careers",Compass],["Analytics & Reports","/admin?tab=reports",ChartNoAxesCombined],["Courses","/admin?tab=courses",BookOpen],["Opportunities","/admin?tab=jobs",BriefcaseBusiness]];
export function AppLayout(){
 const {user,logout}=useAuth(); const nav=useNavigate(); const [mobile,setMobile]=useState(false); const [collapsed,setCollapsed]=useState(false);
 const items=user?.role==="admin"?adminNav:studentNav;
 const side=<aside className={`sidebar ${collapsed?"collapsed":""} ${mobile?"mobile-open":""}`}>
  <div className="brand"><div className="brand-mark"><Sparkles size={20}/></div>{!collapsed&&<span>pathfinder<span className="brand-ai">.ai</span></span>}<button className="sidebar-close" onClick={()=>setMobile(false)}><X size={18}/></button></div>
  <div className="workspace-label">{!collapsed&&"WORKSPACE"}</div>
  <nav>{items.map(([label,path,Icon])=><NavLink key={label} to={path} end={path==="/app/dashboard"||path==="/admin"} onClick={()=>setMobile(false)} className={({isActive})=>`nav-item ${isActive?"active":""}`}><Icon size={18}/>{!collapsed&&<span>{label}</span>}{label==="Notifications"&&!collapsed&&<i className="nav-dot"/>}</NavLink>)}</nav>
  <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><ShieldCheck size={17}/></div>{!collapsed&&<><b>Need career help?</b><span>Explore your personalized guide.</span><button onClick={()=>nav("/app/assessment")}>Start assessment <ChevronRight size={14}/></button></>}</div><button className="nav-item logout" onClick={()=>{logout();nav("/");}}><LogOut size={18}/>{!collapsed&&"Sign out"}</button></div>
  <button className="collapse-btn" onClick={()=>setCollapsed(!collapsed)}>{collapsed?<ChevronRight size={16}/>:<ChevronLeft size={16}/>}</button>
 </aside>;
 return <div className="app-shell">{side}{mobile&&<div className="mobile-scrim" onClick={()=>setMobile(false)}/>}<div className="main-area"><header className="topbar"><button className="mobile-menu" onClick={()=>setMobile(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{items.find(x=>x[1]===location.pathname)?.[0]||"Overview"}</b></div><div className="top-actions"><span className="status-pill"><i/> AI assistant active</span><button className="icon-button" onClick={()=>nav("/app/notifications")}><Bell size={18}/><i/></button><button className="profile-chip" onClick={()=>nav("/app/profile")}><span className="avatar">{user?.name?.[0]||"S"}</span><span>{user?.name||"Student"}</span></button></div></header><main className="content"><Outlet/></main><footer className="app-footer">© 2026 PathFinder AI <span>Helping you build a career with clarity.</span></footer></div></div>;
}
