import { motion } from "framer-motion";
import { ArrowUpRight, Sparkles } from "lucide-react";

export function PageTitle({eyebrow,title,description,action}) {
 return <div className="page-title"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div>;
}
export function StatCard({label,value,change,icon:Icon,tone="blue"}) {
 return <motion.div className="stat-card card" whileHover={{y:-3}} transition={{duration:.18}}>
  <div className={`stat-icon ${tone}`}>{Icon && <Icon size={19}/>}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-change">{change}</div>
 </motion.div>;
}
export function Tag({children,tone="blue"}) { return <span className={`tag ${tone}`}>{children}</span>; }
export function SectionHeading({title,link, onClick}) { return <div className="section-heading"><h2>{title}</h2>{link && <button className="text-link" onClick={onClick}>{link} <ArrowUpRight size={15}/></button>}</div>; }
export function EmptyState({title="Nothing here yet",text="Your information will appear here when it becomes available."}) { return <div className="empty-state"><Sparkles size={24}/><b>{title}</b><span>{text}</span></div>; }
